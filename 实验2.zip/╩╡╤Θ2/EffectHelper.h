//***************************************************************************************
// EffectsHelper.h by X_Jun(MKXJun) (C) 2018-2019 All Rights Reserved.
// Licensed under the MIT License.
//
// ����һЩʵ�õ���Ч��
// Define utility effect classes.
//***************************************************************************************

//
// ��ͷ�ļ���Ҫ�ڰ�����Ч��ʵ�ֵ�Դ�ļ���ʹ�ã��ұ�������Effects.h��d3dUtil.h����
// 

#ifndef EFFECTHELPER_H
#define EFFECTHELPER_H


// ������Ҫ�ڴ���룬�Ӹ�������
template<class DerivedType>
struct AlignedType
{
	static void* operator new(size_t size)
	{
		const size_t alignedSize = __alignof(DerivedType);

		static_assert(alignedSize > 8, "AlignedNew is only useful for types with > 8 byte alignment! Did you forget a __declspec(align) on DerivedType?");

		void* ptr = _aligned_malloc(size, alignedSize);

		if (!ptr)
			throw std::bad_alloc();

		return ptr;
	}

	static void operator delete(void * ptr)
	{
		_aligned_free(ptr);
	}
};

struct CBufferBase
{
	template<class T>
	using ComPtr = Microsoft::WRL::ComPtr<T>;

	BOOL isDirty;
	ComPtr<ID3D11Buffer> cBuffer;

	virtual HRESULT CreateBuffer(ComPtr<ID3D11Device> device) = 0;
	virtual void UpdateBuffer(ComPtr<ID3D11DeviceContext> deviceContext) = 0;
	virtual void BindVS(ComPtr<ID3D11DeviceContext> deviceContext) = 0;
	virtual void BindHS(ComPtr<ID3D11DeviceContext> deviceContext) = 0;
	virtual void BindDS(ComPtr<ID3D11DeviceContext> deviceContext) = 0;
	virtual void BindGS(ComPtr<ID3D11DeviceContext> deviceContext) = 0;
	virtual void BindCS(ComPtr<ID3D11DeviceContext> deviceContext) = 0;
	virtual void BindPS(ComPtr<ID3D11DeviceContext> deviceContext) = 0;
};

template<UINT startSlot, class T>
struct CBufferObject : CBufferBase
{
	T data;

	HRESULT CreateBuffer(ComPtr<ID3D11Device> device) override
	{
		if (cBuffer != nullptr)
			return S_OK;
		D3D11_BUFFER_DESC cbd;
		ZeroMemory(&cbd, sizeof(cbd));
		cbd.Usage = D3D11_USAGE_DYNAMIC;
		cbd.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
		cbd.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
		cbd.ByteWidth = sizeof(T);
		return device->CreateBuffer(&cbd, nullptr, cBuffer.GetAddressOf());
	}

	void UpdateBuffer(ComPtr<ID3D11DeviceContext> deviceContext) override
	{
		if (isDirty)
		{
			isDirty = false;
			D3D11_MAPPED_SUBRESOURCE mappedData;
			deviceContext->Map(cBuffer.Get(), 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedData);
			memcpy_s(mappedData.pData, sizeof(T), &data, sizeof(T));
			deviceContext->Unmap(cBuffer.Get(), 0);
		}
	}

	void BindVS(ComPtr<ID3D11DeviceContext> deviceContext) override
	{
		deviceContext->VSSetConstantBuffers(startSlot, 1, cBuffer.GetAddressOf());
	}

	void BindHS(ComPtr<ID3D11DeviceContext> deviceContext) override
	{
		deviceContext->HSSetConstantBuffers(startSlot, 1, cBuffer.GetAddressOf());
	}

	void BindDS(ComPtr<ID3D11DeviceContext> deviceContext) override
	{
		deviceContext->DSSetConstantBuffers(startSlot, 1, cBuffer.GetAddressOf());
	}

	void BindGS(ComPtr<ID3D11DeviceContext> deviceContext) override
	{
		deviceContext->GSSetConstantBuffers(startSlot, 1, cBuffer.GetAddressOf());
	}

	void BindCS(ComPtr<ID3D11DeviceContext> deviceContext) override
	{
		deviceContext->CSSetConstantBuffers(startSlot, 1, cBuffer.GetAddressOf());
	}

	void BindPS(ComPtr<ID3D11DeviceContext> deviceContext) override
	{
		deviceContext->PSSetConstantBuffers(startSlot, 1, cBuffer.GetAddressOf());
	}
};



#endif

